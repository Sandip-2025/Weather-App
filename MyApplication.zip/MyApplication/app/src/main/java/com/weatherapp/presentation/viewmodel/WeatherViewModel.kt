package com.weatherapp.presentation.viewmodel

import androidx.lifecycle.ViewModel
import androidx.lifecycle.viewModelScope
import com.weatherapp.core.utils.Resource
import com.weatherapp.data.model.WeatherResponse
import com.weatherapp.domain.usecase.GetWeatherUseCase
import kotlinx.coroutines.flow.MutableStateFlow
import kotlinx.coroutines.flow.StateFlow
import kotlinx.coroutines.launch

class WeatherViewModel(private val getWeatherUseCase: GetWeatherUseCase) : ViewModel() {
    private val _weatherState = MutableStateFlow<WeatherState>(WeatherState.Idle)
    val weatherState: StateFlow<WeatherState> = _weatherState

    fun getWeather(city: String) {

        viewModelScope.launch {
            _weatherState.value = WeatherState.Loading
            when (val result = getWeatherUseCase(city)) {
                is Resource.Success<*> -> {
                    _weatherState.value = WeatherState.Success(result.data!!)
                }

                is Resource.Error<*> -> {
                    _weatherState.value = WeatherState.Error(result.message ?: "Unknown Error")
                }

                is Resource.Loading -> {
                    _weatherState.value = WeatherState.Loading
                }
            }
        }
    }

    sealed class WeatherState {
        object Idle : WeatherState()
        object Loading : WeatherState()
        data class Success(val weather: WeatherResponse) : WeatherState()
        data class Error(val message: String) : WeatherState()
    }
}
