package com.weatherapp.data.repository

import com.weatherapp.core.utils.Resource
import com.weatherapp.data.model.WeatherResponse

interface WeatherRepository {
    suspend fun getWeather(city: String): Resource<WeatherResponse>
}