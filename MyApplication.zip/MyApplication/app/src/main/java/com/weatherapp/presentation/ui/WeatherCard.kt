package com.weatherapp.presentation.ui

import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.Spacer
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.height
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.material.Card
import androidx.compose.material.MaterialTheme
import androidx.compose.material.Text
import androidx.compose.runtime.Composable
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.tooling.preview.Preview
import androidx.compose.ui.unit.dp
import com.weatherapp.data.model.WeatherResponse

@Composable
fun WeatherCard(weather: WeatherResponse) {
    Card(
        shape = RoundedCornerShape(16.dp),
        backgroundColor = MaterialTheme.colors.surface.copy(alpha = 0.7f),
        modifier = Modifier
            .fillMaxWidth()
            .padding(horizontal = 16.dp)

    ) {
        Column(
            modifier = Modifier.padding(16.dp),
            horizontalAlignment = Alignment.CenterHorizontally
        ) {
            // City Name and Temperature
            Text(text = weather.location.name, style = MaterialTheme.typography.h2)

            Spacer(modifier = Modifier.height(8.dp))
            Text(text = "${weather.current.temp_c}°C", style = MaterialTheme.typography.h3,)

            // Weather Condition
            Spacer(modifier = Modifier.height(8.dp))
            Text(text = weather.current.condition.text, style = MaterialTheme.typography.body1)

            Spacer(modifier = Modifier.height(16.dp))

            // Additional Weather Details
            Row(
                horizontalArrangement = Arrangement.SpaceEvenly,
                modifier = Modifier.fillMaxWidth()
            ) {
                WeatherDetail("Humidity", "${weather.current.humidity}%")
                WeatherDetail("UV Index", "${weather.current.uv}")
                WeatherDetail("Feels Like", "${weather.current.feelslike_c}°C")
            }
        }
    }
}

@Composable
fun WeatherDetail(label: String, value: String) {
    Column(horizontalAlignment = Alignment.CenterHorizontally) {
        Text(text = label, style = MaterialTheme.typography.caption)
        Text(text = value, style = MaterialTheme.typography.body1)
    }
}

@Preview
@Composable
fun PreviewWeatherScreen() {

}
