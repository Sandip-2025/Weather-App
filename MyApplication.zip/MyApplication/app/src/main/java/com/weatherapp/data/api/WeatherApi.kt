package com.weatherapp.data.api

import com.weatherapp.data.model.WeatherResponse
import retrofit2.http.GET
import retrofit2.http.Query

interface WeatherApi {

    @GET("current.json")
    suspend fun getWeather(
        @Query("key") apiKey: String = "fc6a8abd997e496abde92832242212",
        @Query("q") city: String
    ): WeatherResponse
}
