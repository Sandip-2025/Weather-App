package com.weatherapp.data.repository

import com.weatherapp.core.utils.Constants
import com.weatherapp.core.utils.Resource
import com.weatherapp.data.api.WeatherApi
import com.weatherapp.data.model.WeatherResponse

class WeatherRepositoryImpl(private val api: WeatherApi) : WeatherRepository {
    override suspend fun getWeather(city: String): Resource<WeatherResponse> {
        return try {
            val response = api.getWeather(Constants.API_KEY, city)
            Resource.Success(response)
        } catch (e: Exception) {
            Resource.Error("Error fetching weather: ${e.localizedMessage}")
        }
    }
}
