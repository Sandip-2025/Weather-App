package com.weatherapp.di

import com.weatherapp.data.repository.WeatherRepositoryImpl
import com.weatherapp.data.api.WeatherApi
import com.weatherapp.data.repository.WeatherRepository
import com.weatherapp.domain.usecase.GetWeatherUseCase
import com.weatherapp.presentation.viewmodel.WeatherViewModel
import okhttp3.OkHttpClient
import okhttp3.logging.HttpLoggingInterceptor
import org.koin.androidx.viewmodel.dsl.viewModel
import org.koin.dsl.module
import retrofit2.Retrofit
import retrofit2.converter.gson.GsonConverterFactory

val KoinModule = module {
    single {
        Retrofit.Builder()
            .baseUrl("https://api.weatherapi.com/")
            .addConverterFactory(GsonConverterFactory.create())
            .client(
                OkHttpClient.Builder().addInterceptor(HttpLoggingInterceptor().apply {
                    level = HttpLoggingInterceptor.Level.BODY
                }).build()
            )
            .build()
            .create(WeatherApi::class.java)
    }

    single<WeatherRepository> { WeatherRepositoryImpl(get()) }
    factory { GetWeatherUseCase(get()) }
    viewModel { WeatherViewModel(get()) }
}
