package com.weatherapp.domain.usecase

import com.weatherapp.data.repository.WeatherRepository

class GetWeatherUseCase(private val repository: WeatherRepository) {
    suspend operator fun invoke(city: String) = repository.getWeather(city)
}