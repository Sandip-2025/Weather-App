package com.weatherapp.core.utils

import android.content.Context
import android.content.SharedPreferences

class PreferenceManager(private val context: Context) {

    private val sharedPreferences: SharedPreferences =
        context.getSharedPreferences("weather_prefs", Context.MODE_PRIVATE)

    fun saveCity(city: String) {
        sharedPreferences.edit().putString("last_city", city).apply()
    }

    fun getCity(): String? {
        return sharedPreferences.getString("last_city", null)
    }
}
