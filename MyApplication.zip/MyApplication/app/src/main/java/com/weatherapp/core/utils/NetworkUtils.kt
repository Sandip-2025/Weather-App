package com.weatherapp.core.utils


import android.content.Context
import android.net.ConnectivityManager
import android.net.NetworkInfo

fun isNetworkAvailable(context: Context): Boolean {
    val connectivityManager = context.getSystemService(Context.CONNECTIVITY_SERVICE) as ConnectivityManager
    val activeNetwork: NetworkInfo? = connectivityManager.activeNetworkInfo
    return activeNetwork?.isConnected == true
}
object Constants {
    const val API_KEY = "fc6a8abd997e496abde92832242212"
    const val BASE_URL = "https://api.weatherapi.com/v1/"
}

