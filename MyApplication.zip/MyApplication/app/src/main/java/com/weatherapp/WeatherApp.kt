package com.weatherapp

import android.app.Application
import com.weatherapp.di.KoinModule
import org.koin.android.ext.koin.androidContext
import org.koin.core.context.startKoin

class WeatherApp : Application() {

    override fun onCreate() {
        super.onCreate()
        // Start Koin DI
        startKoin {
            androidContext(this@WeatherApp)  // Use the application context
            modules(KoinModule)  // Load Koin modules
        }
    }

}
