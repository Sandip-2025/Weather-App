package com.weatherapp.presentation.ui

import android.app.Application
import androidx.compose.foundation.Image
import androidx.compose.foundation.background
import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.Box
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.Spacer
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.height
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.layout.size
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.material.CircularProgressIndicator
import androidx.compose.material.Icon
import androidx.compose.material.IconButton
import androidx.compose.material.MaterialTheme
import androidx.compose.material.Text
import androidx.compose.material.TextField
import androidx.compose.material.TextFieldDefaults
import androidx.compose.material.contentColorFor
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.filled.Search
import androidx.compose.runtime.Composable
import androidx.compose.runtime.MutableState
import androidx.compose.runtime.collectAsState
import androidx.compose.runtime.getValue
import androidx.compose.runtime.mutableStateOf
import androidx.compose.runtime.remember
import androidx.compose.runtime.setValue
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.platform.LocalContext
import androidx.compose.ui.text.input.TextFieldValue
import androidx.compose.ui.unit.dp
import coil.compose.rememberAsyncImagePainter
import coil.request.ImageRequest
import com.weatherapp.R
import com.weatherapp.core.utils.Constants
import com.weatherapp.core.utils.PreferenceManager
import com.weatherapp.data.api.WeatherApi
import com.weatherapp.data.repository.WeatherRepositoryImpl
import com.weatherapp.domain.usecase.GetWeatherUseCase
import com.weatherapp.presentation.viewmodel.WeatherViewModel
import retrofit2.Retrofit
import retrofit2.converter.gson.GsonConverterFactory.create

@Composable
fun HomeScreen() {

    val viewModel = remember {
        val api = Retrofit.Builder().baseUrl(Constants.BASE_URL)
            .addConverterFactory(create()).build().create(WeatherApi::class.java)
        val repository = WeatherRepositoryImpl(api)
        val useCase = GetWeatherUseCase(repository)
        WeatherViewModel(useCase)
    }

    val weatherState by viewModel.weatherState.collectAsState()
//    val city: MutableState<TextFieldValue> =
//        remember { androidx.compose.runtime.mutableStateOf(TextFieldValue()) }

    var city = remember { mutableStateOf("") }
    var inputCity = remember { mutableStateOf("") }

    val context = LocalContext.current.applicationContext as Application

    PreferenceManager(context).getCity()?.let {
        if (it.isNotEmpty()) {
            viewModel.getWeather(it.trim())
        } else {
            ShowErrorScreen(it)
        }
    }

    Box(
        modifier = Modifier
            .fillMaxSize()
            .background(Color.White),
        contentAlignment = Alignment.TopCenter
    )

    {
        Column(
            modifier = Modifier
                .fillMaxSize()
                .padding(16.dp),
            horizontalAlignment = Alignment.CenterHorizontally,
            verticalArrangement = Arrangement.Top
        ) {
            // Search Box
            TextField(value = city.value,
                onValueChange = { city.value = it },
                placeholder = { Text("Search Location") },
                modifier = Modifier.fillMaxWidth(),
                shape = RoundedCornerShape(8.dp),
                colors = TextFieldDefaults.textFieldColors(
                    backgroundColor = MaterialTheme.colors.surface.copy(alpha = 0.5f),
                    focusedIndicatorColor = Color.LightGray,
                    unfocusedIndicatorColor = Color.LightGray
                ),
                trailingIcon = {
                    IconButton(onClick = {
                         inputCity = city
                        viewModel.getWeather(inputCity.value)
                        PreferenceManager(context).saveCity(inputCity.value)
                    }) {
                        Icon(
                            imageVector = Icons.Default.Search, contentDescription = "Search Icon"
                        )
                    }
                })

            Spacer(modifier = Modifier.height(1.dp))

            // Weather Info Card
            when (val state = weatherState) {
                is WeatherViewModel.WeatherState.Success -> {

                    Column(horizontalAlignment = Alignment.CenterHorizontally) {
                        // Weather Icon
                        Image(
                            painter = // Optional placeholder
                            rememberAsyncImagePainter(
                                ImageRequest.Builder(LocalContext.current).data(
                                    data = "https:${state.weather.current.condition.icon}" // URL of the icon
                                ).apply(block = fun ImageRequest.Builder.() {
                                    crossfade(true)
                                    placeholder(R.drawable.ic_rainy) // Optional placeholder
                                }).build()
                            ),
                            contentDescription = "Weather Icon",
                            modifier = Modifier
                                .size(100.dp)
                                .padding(8.dp)
                        )

                        // Weather Card
                        WeatherCard(state.weather)
                    }
                }

                is WeatherViewModel.WeatherState.Error -> {
                    ShowErrorScreen(state.message)
                }

                WeatherViewModel.WeatherState.Loading -> {
                    CircularProgressIndicator()
                }

                else -> {}
            }
        }
    }
}

@Composable
fun ShowErrorScreen(message: String) {
    Column(
        modifier = Modifier.padding(16.dp),
        horizontalAlignment = Alignment.CenterHorizontally
    ) {
        Text(
            text = "Error: ${message}",
            color = MaterialTheme.colors.error,
            style = MaterialTheme.typography.body1
        )
        Text(
            text = "No City Selected",
            color = MaterialTheme.colors.contentColorFor(Color.Black),
            style = MaterialTheme.typography.h4,
        )
        Text(
            text = "Please Search For A City",
            color = MaterialTheme.colors.contentColorFor(Color.Black),
            style = MaterialTheme.typography.body1,
            fontStyle = MaterialTheme.typography.body1.fontStyle
        )
    }
}